export interface TargetCombination {
  id: string;
  age: string;
  city: string;
  permission: string;
  gender: string;
  totalIntersection: number;
  availableIntersection: number;
  volumeType: 'max' | 'custom';
  volumeCustom?: number;
  plannedSendVolume: number;
}

export interface TargetGroup {
  ages: string[];
  cities: string[];
  permissions: string[];
  genders: string[];
}

export interface Campaign {
  id: string;
  name: string;
  manager: string;
  sendDate: string;
  channel: 'email' | 'sms' | 'portal';
  messageContent?: string;
  
  targetGroup: TargetGroup;
  combinations: TargetCombination[];
  
  // Overall aggregated stats
  intersectionTotalSize: number;
  intersectionAvailableSize: number;
  plannedSendVolume: number; 
  
  status: 'planned' | 'sent' | 'failed' | 'in_progress';
  createdAt: string;
  updatedAt?: string;
}

export interface DatabaseStats {
  totalClients: number;
  availableClients: number;
  lastUpdated: string;
}
