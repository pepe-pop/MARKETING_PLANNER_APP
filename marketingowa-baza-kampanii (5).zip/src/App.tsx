import { useState, useEffect } from 'react';
import { CampaignTable } from '@/components/CampaignTable';
import { CampaignForm } from '@/components/CampaignForm';
import { CampaignDetails } from '@/components/CampaignDetails';
import { DatabaseStatsComponent } from '@/components/DatabaseStats';
import { getCampaigns } from '@/utils/localStorage';
import { Campaign } from '@/types/campaign';
import { PlusCircle, FileSpreadsheet, Database } from 'lucide-react';

export function App() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [campaignToEdit, setCampaignToEdit] = useState<Campaign | undefined>(undefined);
  const [campaignToView, setCampaignToView] = useState<Campaign | undefined>(undefined);
  const [activeTab, setActiveTab] = useState<'campaigns' | 'database'>('campaigns');

  useEffect(() => {
    setCampaigns(getCampaigns());
  }, []);

  const handleCampaignAddedOrEdited = () => {
    setCampaigns(getCampaigns());
    setIsFormOpen(false);
    setCampaignToEdit(undefined);
  };

  const handleOpenAddForm = () => {
    setCampaignToEdit(undefined);
    setIsFormOpen(true);
  };

  const handleEditCampaign = (campaign: Campaign) => {
    setCampaignToEdit(campaign);
    setIsFormOpen(true);
  };

  const handleViewDetails = (campaign: Campaign) => {
    setCampaignToView(campaign);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileSpreadsheet className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Plan Kampanii Marketingowych</h1>
                <p className="text-sm text-gray-500">Narzędzie do zarządzania kampaniami marketingowymi</p>
              </div>
            </div>
            {activeTab === 'campaigns' && (
              <button
                onClick={handleOpenAddForm}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow-sm"
              >
                <PlusCircle className="h-5 w-5" />
                <span>Dodaj kampanię</span>
              </button>
            )}
          </div>

          <div className="mt-4 flex space-x-8">
            <button
              onClick={() => setActiveTab('campaigns')}
              className={`flex items-center space-x-2 px-1 py-2 border-b-2 font-medium text-sm ${
                activeTab === 'campaigns'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <FileSpreadsheet className="h-5 w-5" />
              <span>Plan kampanii</span>
            </button>
            <button
              onClick={() => setActiveTab('database')}
              className={`flex items-center space-x-2 px-1 py-2 border-b-2 font-medium text-sm ${
                activeTab === 'database'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Database className="h-5 w-5" />
              <span>Stan bazy danych</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'campaigns' ? (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <CampaignTable
                campaigns={campaigns}
                onEdit={handleEditCampaign}
                onViewDetails={handleViewDetails}
              />
            </div>
          </div>
        ) : (
          <DatabaseStatsComponent />
        )}
      </main>

      {isFormOpen && (
        <CampaignForm
          campaignToEdit={campaignToEdit}
          onClose={handleCampaignAddedOrEdited}
        />
      )}

      {campaignToView && (
        <CampaignDetails
          campaign={campaignToView}
          onClose={() => setCampaignToView(undefined)}
        />
      )}
    </div>
  );
}
