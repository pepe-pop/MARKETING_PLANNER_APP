import { useState, useEffect, useRef } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { z } from 'zod';
import { Campaign, TargetCombination } from '@/types/campaign';
import { saveCampaign, updateCampaign, getCampaigns, getCampaignsVersion } from '@/utils/localStorage';
import { exportCampaignsToExcel } from '@/utils/excelExport';
import { calculateIntersection } from '@/utils/baseCalculator';
import { format } from 'date-fns';
import { X, Mail, MessageSquare, Globe, Calculator, Save, Info } from 'lucide-react';
import { CITIES, PERMISSIONS, AGE_RANGES, GENDERS } from '@/config';
import { MultiSelect } from './MultiSelect';
import { cn } from '@/utils/cn';

const campaignSchema = z.object({
  name: z.string().min(1, 'Nazwa kampanii jest wymagana'),
  manager: z.string().min(1, 'Opiekun linii jest wymagany'),
  sendDate: z.string().min(1, 'Data wysyłki jest wymagana'),
  channel: z.enum(['email', 'sms', 'portal']),
  messageContent: z.string().optional(),
  status: z.enum(['planned', 'sent', 'failed', 'in_progress'])
});

type CampaignFormData = z.infer<typeof campaignSchema>;

interface CampaignFormProps {
  onClose: () => void;
  campaignToEdit?: Campaign;
}

export const CampaignForm: React.FC<CampaignFormProps> = ({ onClose, campaignToEdit }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ages, setAges] = useState<string[]>(campaignToEdit?.targetGroup?.ages || []);
  const [cities, setCities] = useState<string[]>(campaignToEdit?.targetGroup?.cities || []);
  const [permissions, setPermissions] = useState<string[]>(campaignToEdit?.targetGroup?.permissions || []);
  const [genders, setGenders] = useState<string[]>(campaignToEdit?.targetGroup?.genders || []);
  
  const [combinations, setCombinations] = useState<TargetCombination[]>(campaignToEdit?.combinations || []);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<CampaignFormData>({
    defaultValues: campaignToEdit ? {
      name: campaignToEdit.name,
      manager: campaignToEdit.manager,
      sendDate: campaignToEdit.sendDate,
      channel: campaignToEdit.channel,
      messageContent: campaignToEdit.messageContent,
      status: campaignToEdit.status,
    } : {
      channel: 'email',
      status: 'planned'
    },
  });

  const channel = useWatch({ control, name: 'channel' });
  const sendDate = useWatch({ control, name: 'sendDate' });

  // Update combinations when filters change
  useEffect(() => {
    if (!sendDate || ages.length === 0 || cities.length === 0 || permissions.length === 0 || genders.length === 0) {
      if (combinations.length > 0) setCombinations([]);
      return;
    }

    const allCampaigns = getCampaigns();
    const newCombos: TargetCombination[] = [];
    
    ages.forEach(age => {
      cities.forEach(city => {
        permissions.forEach(permission => {
          genders.forEach(gender => {
             const id = `${age}|${city}|${permission}|${gender}`;
             const existing = combinations.find(c => c.id === id);
             const stats = calculateIntersection(
               {age, city, permission, gender}, 
               sendDate, 
               allCampaigns, 
               campaignToEdit?.id
             );
             
             if (existing) {
               // Jeżeli mamy zablokowaną bazę, a wolumen "custom" był większy, musimy go obciąć
               const safeCustom = Math.min(existing.volumeCustom || 0, stats.availableIntersection);
               newCombos.push({
                 ...existing,
                 totalIntersection: stats.totalIntersection,
                 availableIntersection: stats.availableIntersection,
                 volumeCustom: existing.volumeType === 'custom' ? safeCustom : existing.volumeCustom,
                 plannedSendVolume: existing.volumeType === 'max' ? stats.availableIntersection : safeCustom
               });
             } else {
               newCombos.push({
                 id, age, city, permission, gender,
                 totalIntersection: stats.totalIntersection,
                 availableIntersection: stats.availableIntersection,
                 volumeType: 'max',
                 plannedSendVolume: stats.availableIntersection
               });
             }
          })
        })
      })
    });
    
    const isSame = newCombos.length === combinations.length && 
                   newCombos.every((nc, i) => nc.id === combinations[i]?.id && nc.availableIntersection === combinations[i]?.availableIntersection && nc.plannedSendVolume === combinations[i]?.plannedSendVolume);
                   
    if (!isSame) {
      setCombinations(newCombos);
    }
  }, [ages, cities, permissions, genders, sendDate, campaignToEdit?.id]);

  const updateCombinationVolume = (id: string, type: 'max' | 'custom', customVal?: number) => {
    setCombinations(prev => prev.map(c => {
      if (c.id !== id) return c;
      const planned = type === 'max' ? c.availableIntersection : (customVal || 0);
      return { ...c, volumeType: type, volumeCustom: customVal, plannedSendVolume: planned };
    }));
  };

  const initialVersion = useRef(getCampaignsVersion());

  const onSubmit = async (data: CampaignFormData) => {
    setIsSubmitting(true);

    if (combinations.length === 0) {
      alert("Wybierz kryteria grupy docelowej aby wygenerować kombinacje.");
      setIsSubmitting(false);
      return;
    }

    // Check for concurrent changes
    const currentVersion = getCampaignsVersion();
    if (currentVersion !== initialVersion.current) {
      const allCampaigns = getCampaigns();
      let hasConflict = false;
      
      for (const c of combinations) {
         const stats = calculateIntersection(
           {age: c.age, city: c.city, permission: c.permission, gender: c.gender}, 
           data.sendDate, 
           allCampaigns, 
           campaignToEdit?.id
         );
         if (stats.availableIntersection < c.plannedSendVolume) {
           hasConflict = true;
           break;
         }
      }

      if (hasConflict) {
        alert("Uwaga! W międzyczasie inna osoba zarezerwowała część wybranej przez Ciebie bazy lub zaszły zmiany w systemie. Twoja zaplanowana wielkość wysyłki przekracza nową dostępną pulę. Odśwież formularz lub zmniejsz wolumen.");
        setIsSubmitting(false);
        return;
      }
    }

    // Check custom volume limits
    const invalidCombo = combinations.find(c => c.volumeType === 'custom' && (c.volumeCustom || 0) > c.availableIntersection);
    if (invalidCombo) {
      alert(`Wpisana liczba kontaktów dla kombinacji [${invalidCombo.age}, ${invalidCombo.city}, ${invalidCombo.permission}, ${invalidCombo.gender}] przekracza dostępną bazę!`);
      setIsSubmitting(false);
      return;
    }

    const totalIntersection = combinations.reduce((sum, c) => sum + c.totalIntersection, 0);
    const totalAvailable = combinations.reduce((sum, c) => sum + c.availableIntersection, 0);
    const totalPlanned = combinations.reduce((sum, c) => sum + c.plannedSendVolume, 0);

    const campaignData = {
      name: data.name,
      manager: data.manager,
      sendDate: data.sendDate,
      channel: data.channel,
      messageContent: data.messageContent,
      targetGroup: { ages, cities, permissions, genders },
      combinations,
      intersectionTotalSize: totalIntersection,
      intersectionAvailableSize: totalAvailable,
      plannedSendVolume: totalPlanned,
      status: data.status,
    };

    if (campaignToEdit) {
      const updatedCampaign: Campaign = {
        ...campaignToEdit,
        ...campaignData,
        updatedAt: format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
      };
      updateCampaign(campaignToEdit.id, updatedCampaign);
    } else {
      const newCampaign: Campaign = {
        id: Date.now().toString(),
        ...campaignData,
        createdAt: format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
      };
      saveCampaign(newCampaign);
    }
    
    exportCampaignsToExcel(getCampaigns());
    setIsSubmitting(false);
    onClose();
  };

  // UI calculations for total summary
  const totalAvail = combinations.reduce((sum, c) => sum + c.availableIntersection, 0);
  const totalPlanned = combinations.reduce((sum, c) => sum + c.plannedSendVolume, 0);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[95vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b bg-gray-50 rounded-t-lg shrink-0">
          <h2 className="text-xl font-semibold text-gray-900">
            {campaignToEdit ? 'Edytuj kampanię' : 'Dodaj nową kampanię'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <form id="campaign-form" onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Kolumna 1: Informacje podstawowe */}
              <div className="space-y-4 md:col-span-1">
                <h3 className="text-sm font-medium text-gray-900 border-b pb-2">Dane podstawowe</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nazwa kampanii *</label>
                  <input {...register('name')} type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" />
                  {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Opiekun linii *</label>
                  <input {...register('manager')} type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" />
                  {errors.manager && <p className="text-red-500 text-xs mt-1">{errors.manager.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Planowana data wysyłki *</label>
                  <input {...register('sendDate')} type="date" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" />
                  {errors.sendDate && <p className="text-red-500 text-xs mt-1">{errors.sendDate.message}</p>}
                </div>

                {campaignToEdit && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status realizacji</label>
                    <select {...register('status')} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                      <option value="planned">Planowana</option>
                      <option value="in_progress">W trakcie</option>
                      <option value="sent">Wysłana</option>
                      <option value="failed">Nieudana</option>
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Kanał kontaktu *</label>
                  <div className="flex flex-col gap-2">
                    <label className={cn("flex items-center space-x-2 p-2 border rounded-md cursor-pointer transition-colors", channel === 'email' ? "bg-blue-50 border-blue-200" : "border-gray-300 hover:bg-gray-50")}>
                      <input {...register('channel')} type="radio" value="email" className="text-blue-600" />
                      <Mail className="h-5 w-5 text-blue-600" />
                      <span className="text-sm font-medium">Email</span>
                    </label>
                    <label className={cn("flex items-center space-x-2 p-2 border rounded-md cursor-pointer transition-colors", channel === 'sms' ? "bg-green-50 border-green-200" : "border-gray-300 hover:bg-gray-50")}>
                      <input {...register('channel')} type="radio" value="sms" className="text-green-600" />
                      <MessageSquare className="h-5 w-5 text-green-600" />
                      <span className="text-sm font-medium">SMS</span>
                    </label>
                    <label className={cn("flex items-center space-x-2 p-2 border rounded-md cursor-pointer transition-colors", channel === 'portal' ? "bg-purple-50 border-purple-200" : "border-gray-300 hover:bg-gray-50")}>
                      <input {...register('channel')} type="radio" value="portal" className="text-purple-600" />
                      <Globe className="h-5 w-5 text-purple-600" />
                      <span className="text-sm font-medium">Portal</span>
                    </label>
                  </div>
                </div>

                {channel === 'sms' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Treść komunikatu SMS</label>
                    <textarea {...register('messageContent')} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="Wpisz treść wiadomości SMS..." />
                  </div>
                )}
              </div>

              {/* Kolumna 2 i 3: Grupa Docelowa i Kombinacje */}
              <div className="md:col-span-2 space-y-6 pb-20">
                <h3 className="text-sm font-medium text-gray-900 border-b pb-2 flex items-center">
                  <Calculator className="h-4 w-4 mr-2 text-blue-600" /> Kryteria Grupy Docelowej (Wybór Wielokrotny)
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 p-4 rounded-lg">
                  <MultiSelect label="Wiek" options={AGE_RANGES} selected={ages} onChange={setAges} />
                  <MultiSelect label="Miasto" options={CITIES} selected={cities} onChange={setCities} />
                  <MultiSelect label="Uprawnienie" options={PERMISSIONS} selected={permissions} onChange={setPermissions} />
                  <MultiSelect label="Płeć" options={GENDERS} selected={genders} onChange={setGenders} />
                </div>

                {combinations.length > 0 ? (
                  <div className="space-y-4">
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-md font-semibold text-gray-900">Szczegóły kombinacji ({combinations.length})</h4>
                        <div className="text-sm bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-medium">
                          Łącznie wysyłka: {totalPlanned.toLocaleString()} / {totalAvail.toLocaleString()}
                        </div>
                      </div>
                      <div className="text-xs text-amber-600 bg-amber-50 p-2 rounded border border-amber-100 flex items-center">
                        <Info className="h-4 w-4 mr-1 shrink-0" />
                        Dostępna baza w tabeli poniżej jest pomniejszona automatycznie, jeśli inna kampania dla tego przekroju została zaplanowana w okresie ±7 dni.
                      </div>
                    </div>
                    
                    <div className="border rounded-md overflow-hidden max-h-80 overflow-y-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50 sticky top-0 z-10">
                          <tr>
                            <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Kryteria (W|M|U|P)</th>
                            <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">Dostępna Baza</th>
                            <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Wolumen</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {combinations.map((c) => (
                            <tr key={c.id} className="hover:bg-gray-50">
                              <td className="px-3 py-2 text-xs text-gray-900">
                                {c.age}, {c.city}, {c.permission}, {c.gender}
                              </td>
                              <td className="px-3 py-2 text-xs font-semibold text-right text-gray-900">
                                {c.availableIntersection.toLocaleString()}
                              </td>
                              <td className="px-3 py-2 text-xs whitespace-nowrap">
                                <div className="flex items-center space-x-2">
                                  <select 
                                    className="border border-gray-300 rounded px-2 py-1 text-xs"
                                    value={c.volumeType}
                                    onChange={(e) => updateCombinationVolume(c.id, e.target.value as 'max' | 'custom', c.volumeCustom)}
                                  >
                                    <option value="max">Max</option>
                                    <option value="custom">Własna</option>
                                  </select>
                                  {c.volumeType === 'custom' && (
                                    <input 
                                      type="number" 
                                      className={cn("border rounded px-2 py-1 w-20 text-xs", (c.volumeCustom || 0) > c.availableIntersection ? "border-red-500 bg-red-50" : "border-gray-300")}
                                      value={c.volumeCustom || ''}
                                      min="0"
                                      onChange={(e) => updateCombinationVolume(c.id, 'custom', parseInt(e.target.value) || 0)}
                                      placeholder="Liczba"
                                    />
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white p-6 border rounded-lg text-center text-sm text-gray-500">
                    Wybierz co najmniej jedną wartość w każdym z 4 filtrów powyżej oraz określ datę wysyłki, aby wygenerować kombinacje bazy.
                  </div>
                )}

              </div>
            </div>
          </form>
        </div>

        <div className="border-t bg-gray-50 px-6 py-4 flex justify-end shrink-0 rounded-b-lg">
          <button
            type="button"
            onClick={onClose}
            className="mr-3 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
          >
            Anuluj
          </button>
          <button
            type="submit"
            form="campaign-form"
            disabled={isSubmitting || combinations.length === 0}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Save className="h-4 w-4" />
            <span>{isSubmitting ? 'Zapisywanie...' : 'Zapisz i Generuj Excel'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
