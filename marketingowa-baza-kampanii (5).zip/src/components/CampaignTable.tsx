import React, { useMemo, useState } from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { Campaign } from '@/types/campaign';
import { Filter, SortAsc, SortDesc, Edit, Info, Calendar as CalendarIcon, Table as TableIcon } from 'lucide-react';
import { cn } from '@/utils/cn';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameDay } from 'date-fns';
import { pl } from 'date-fns/locale';

interface CampaignTableProps {
  campaigns: Campaign[];
  onEdit: (campaign: Campaign) => void;
  onViewDetails: (campaign: Campaign) => void;
}

export const CampaignTable: React.FC<CampaignTableProps> = ({ campaigns, onEdit, onViewDetails }) => {
  const [viewMode, setViewMode] = useState<'table' | 'calendar'>('table');
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  const [currentDate, setCurrentDate] = useState(new Date());

  const filteredCampaigns = useMemo(() => {
    return campaigns.filter(c => {
      if (channelFilter !== 'all' && c.channel !== channelFilter) return false;
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      return true;
    });
  }, [campaigns, channelFilter, statusFilter]);

  const columns = useMemo<ColumnDef<Campaign>[]>(
    () => [
      {
        accessorKey: 'name',
        header: 'Nazwa kampanii',
        cell: ({ row }) => <div className="font-medium">{row.getValue('name')}</div>,
      },
      {
        accessorKey: 'manager',
        header: 'Opiekun linii',
      },
      {
        accessorKey: 'sendDate',
        header: 'Data wysyłki',
      },
      {
        accessorKey: 'channel',
        header: 'Kanał',
        cell: ({ row }) => {
          const channel = row.getValue<string>('channel');
          return (
            <span
              className={cn(
                'px-2 py-1 rounded-full text-xs font-medium',
                channel === 'email' && 'bg-blue-100 text-blue-800',
                channel === 'sms' && 'bg-green-100 text-green-800',
                channel === 'portal' && 'bg-purple-100 text-purple-800'
              )}
            >
              {channel}
            </span>
          );
        },
      },
      {
        accessorKey: 'status',
        header: 'Status',
        cell: ({ row }) => {
          const status = row.getValue<string>('status');
          const statusMap: Record<string, string> = {
            'planned': 'Planowana',
            'sent': 'Wysłana',
            'failed': 'Nieudana',
            'in_progress': 'W trakcie'
          };
          return (
            <span
              className={cn(
                'px-2 py-1 rounded-full text-xs font-medium',
                status === 'planned' && 'bg-yellow-100 text-yellow-800',
                status === 'sent' && 'bg-green-100 text-green-800',
                status === 'failed' && 'bg-red-100 text-red-800',
                status === 'in_progress' && 'bg-blue-100 text-blue-800'
              )}
            >
              {statusMap[status] || status}
            </span>
          );
        },
      },
      {
        accessorKey: 'plannedSendVolume',
        header: 'Liczba do wysyłki',
        cell: ({ row }) => {
          const volume = row.getValue<number>('plannedSendVolume');
          return <div className="text-right">{volume?.toLocaleString() || 0}</div>;
        },
      },
      {
        id: 'actions',
        header: 'Akcje',
        cell: ({ row }) => (
          <div className="flex space-x-2 justify-end">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onViewDetails(row.original);
              }}
              className="p-1 text-gray-500 hover:text-blue-600 transition-colors"
              title="Szczegóły"
            >
              <Info className="h-4 w-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onEdit(row.original);
              }}
              className="p-1 text-gray-500 hover:text-blue-600 transition-colors"
              title="Edytuj"
            >
              <Edit className="h-4 w-4" />
            </button>
          </div>
        ),
      },
    ],
    [onEdit, onViewDetails]
  );

  const table = useReactTable({
    data: filteredCampaigns,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    initialState: {
      pagination: {
        pageSize: 10,
      },
    },
  });

  const renderCalendar = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const days = eachDayOfInterval({ start, end });
    const startDayOfWeek = getDay(start);
    const offset = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1; 

    return (
      <div className="bg-white shadow-sm ring-1 ring-gray-200 rounded-xl overflow-hidden mt-4">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-white">
          <h3 className="text-lg font-semibold text-gray-900 capitalize flex items-center">
            {format(currentDate, 'MMMM yyyy', { locale: pl })}
          </h3>
          <div className="flex items-center space-x-1 bg-gray-50 p-1 rounded-lg ring-1 ring-gray-200/50">
            <button 
              onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))}
              className="px-3 py-1.5 rounded-md hover:bg-white hover:shadow-sm text-sm font-medium text-gray-600 transition-all"
            >
              Poprzedni
            </button>
            <button 
              onClick={() => setCurrentDate(new Date())}
              className="px-3 py-1.5 rounded-md hover:bg-white hover:shadow-sm text-sm font-medium text-gray-600 transition-all"
            >
              Dziś
            </button>
            <button 
              onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))}
              className="px-3 py-1.5 rounded-md hover:bg-white hover:shadow-sm text-sm font-medium text-gray-600 transition-all"
            >
              Następny
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-7 border-b border-gray-100 bg-gray-50/50">
          {['Pon', 'Wto', 'Śro', 'Czw', 'Pią', 'Sob', 'Nie'].map((day) => (
            <div key={day} className="py-3 text-center text-[11px] uppercase tracking-wider font-semibold text-gray-500 border-r border-gray-100 last:border-0">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7">
          {Array.from({ length: offset }).map((_, i) => (
            <div key={`empty-${i}`} className="min-h-[130px] p-2 border-r border-b border-gray-100 bg-gray-50/30"></div>
          ))}
          {days.map((day) => {
            const dayCampaigns = filteredCampaigns.filter(c => c.sendDate === format(day, 'yyyy-MM-dd'));
            const isToday = isSameDay(day, new Date());
            
            return (
              <div key={day.toISOString()} className="min-h-[130px] p-2 border-r border-b border-gray-100 last:border-r-0 relative group hover:bg-gray-50/50 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <span className={cn(
                    "text-sm font-semibold w-7 h-7 flex items-center justify-center rounded-full ring-1 ring-transparent",
                    isToday ? "bg-blue-600 text-white shadow-md ring-blue-600" : "text-gray-700 group-hover:bg-gray-100"
                  )}>
                    {format(day, 'd')}
                  </span>
                  {dayCampaigns.length > 0 && (
                    <span className="text-[10px] font-medium text-gray-400 mt-1 mr-1">
                      {dayCampaigns.length} kamp.
                    </span>
                  )}
                </div>
                
                <div className="space-y-1.5">
                  {dayCampaigns.map(c => (
                    <div 
                      key={c.id} 
                      onClick={() => onViewDetails(c)}
                      className={cn(
                        "text-xs p-2 rounded-md truncate cursor-pointer transition-all border shadow-sm hover:shadow",
                        c.channel === 'email' && 'bg-blue-50/80 border-blue-200 hover:border-blue-300 text-blue-800',
                        c.channel === 'sms' && 'bg-green-50/80 border-green-200 hover:border-green-300 text-green-800',
                        c.channel === 'portal' && 'bg-purple-50/80 border-purple-200 hover:border-purple-300 text-purple-800'
                      )}
                      title={c.name}
                    >
                      <div className="font-semibold truncate">{c.name}</div>
                      <div className="opacity-80 text-[10px] font-medium mt-0.5">{c.plannedSendVolume.toLocaleString()} szt.</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-2 border border-gray-300 rounded-md px-3 py-1.5 bg-white">
            <Filter className="h-4 w-4 text-gray-500" />
            <select
              className="text-sm bg-transparent outline-none text-gray-700"
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value)}
            >
              <option value="all">Wszystkie kanały</option>
              <option value="email">Email</option>
              <option value="sms">SMS</option>
              <option value="portal">Portal</option>
            </select>
          </div>
          <div className="flex items-center space-x-2 border border-gray-300 rounded-md px-3 py-1.5 bg-white">
            <Filter className="h-4 w-4 text-gray-500" />
            <select
              className="text-sm bg-transparent outline-none text-gray-700"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Wszystkie statusy</option>
              <option value="planned">Planowana</option>
              <option value="in_progress">W trakcie</option>
              <option value="sent">Wysłana</option>
              <option value="failed">Nieudana</option>
            </select>
          </div>
        </div>
        
        <div className="flex bg-gray-100 p-1 rounded-lg">
          <button
            onClick={() => setViewMode('table')}
            className={cn(
              "flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
              viewMode === 'table' ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <TableIcon className="h-4 w-4" />
            <span>Tabela</span>
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={cn(
              "flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
              viewMode === 'calendar' ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <CalendarIcon className="h-4 w-4" />
            <span>Kalendarz</span>
          </button>
        </div>
      </div>

      {viewMode === 'table' ? (
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
             <input
              type="text"
              placeholder="Wyszukaj w tabeli..."
              className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:ring-blue-500 focus:border-blue-500"
              onChange={(e) =>
                table.setGlobalFilter(e.target.value || undefined)
              }
            />
          </div>
          <div className="rounded-md border overflow-x-auto">
            <table className="w-full">
              <thead>
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr key={headerGroup.id} className="bg-gray-50">
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b whitespace-nowrap"
                      >
                        {header.isPlaceholder ? null : (
                          <div
                            className={cn(
                              'flex items-center space-x-1 cursor-pointer',
                              header.column.getCanSort() && 'hover:text-gray-700'
                            )}
                            onClick={header.column.getToggleSortingHandler()}
                          >
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                            {header.column.getIsSorted() === 'asc' ? (
                              <SortAsc className="h-3 w-3 text-gray-400" />
                            ) : header.column.getIsSorted() === 'desc' ? (
                              <SortDesc className="h-3 w-3 text-gray-400" />
                            ) : null}
                          </div>
                        )}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>
              <tbody className="divide-y divide-gray-200">
                {table.getRowModel().rows.map((row) => (
                  <tr
                    key={row.id}
                    className="bg-white hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => onViewDetails(row.original)}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td
                        key={cell.id}
                        className="px-4 py-3 text-sm text-gray-700 whitespace-nowrap"
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
                {table.getRowModel().rows.length === 0 && (
                  <tr>
                    <td colSpan={columns.length} className="px-4 py-8 text-center text-gray-500 text-sm">
                      Brak kampanii spełniających kryteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between px-4 py-2 border-t bg-white rounded-b-md">
            <div className="text-sm text-gray-500">
              Pokazuje {table.getRowModel().rows.length} z {table.getPrePaginationRowModel().rows.length} kampanii
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
                className="px-3 py-1 rounded-md border border-gray-300 text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
              >
                Poprzednia
              </button>
              <button
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
                className="px-3 py-1 rounded-md border border-gray-300 text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
              >
                Następna
              </button>
            </div>
          </div>
        </div>
      ) : (
        renderCalendar()
      )}
    </div>
  );
};
