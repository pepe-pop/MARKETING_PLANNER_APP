import React from 'react';
import { Campaign } from '@/types/campaign';
import { X, Calendar, User, Mail, MessageSquare, Globe, Target, Hash } from 'lucide-react';

interface CampaignDetailsProps {
  campaign: Campaign;
  onClose: () => void;
}

export const CampaignDetails: React.FC<CampaignDetailsProps> = ({ campaign, onClose }) => {
  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'email': return <Mail className="h-5 w-5 text-blue-600" />;
      case 'sms': return <MessageSquare className="h-5 w-5 text-green-600" />;
      case 'portal': return <Globe className="h-5 w-5 text-purple-600" />;
      default: return null;
    }
  };

  const getStatusLabel = (status: string) => {
    const map: Record<string, string> = {
      'planned': 'Planowana',
      'sent': 'Wysłana',
      'failed': 'Nieudana',
      'in_progress': 'W trakcie'
    };
    return map[status] || status;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b bg-gray-50 rounded-t-lg">
          <div className="flex items-center space-x-3">
            {getChannelIcon(campaign.channel)}
            <h2 className="text-xl font-semibold text-gray-900">{campaign.name}</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider flex items-center">
                <InfoIcon className="h-4 w-4 mr-2" />
                Informacje ogólne
              </h3>
              
              <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                <div className="flex items-center text-sm">
                  <User className="h-4 w-4 text-gray-500 mr-2" />
                  <span className="text-gray-500 w-32">Opiekun linii:</span>
                  <span className="font-medium text-gray-900">{campaign.manager}</span>
                </div>
                
                <div className="flex items-center text-sm">
                  <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                  <span className="text-gray-500 w-32">Data wysyłki:</span>
                  <span className="font-medium text-gray-900">{campaign.sendDate}</span>
                </div>
                
                <div className="flex items-center text-sm">
                  <Hash className="h-4 w-4 text-gray-500 mr-2" />
                  <span className="text-gray-500 w-32">Status:</span>
                  <span className="font-medium px-2 py-0.5 bg-gray-200 rounded-full text-xs">
                    {getStatusLabel(campaign.status)}
                  </span>
                </div>
              </div>
              
              {campaign.channel === 'sms' && campaign.messageContent && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Treść SMS:</h4>
                  <div className="bg-green-50 text-green-800 p-3 rounded-md text-sm italic border border-green-100">
                    "{campaign.messageContent}"
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider flex items-center">
                <Target className="h-4 w-4 mr-2" />
                Grupa docelowa
              </h3>
              
              <div className="bg-blue-50 p-4 rounded-lg space-y-3 border border-blue-100">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-gray-600">Wiek:</div>
                  <div className="font-medium truncate" title={campaign.targetGroup.ages?.join(', ')}>{campaign.targetGroup.ages?.join(', ') || '-'}</div>
                  
                  <div className="text-gray-600">Miasto:</div>
                  <div className="font-medium truncate" title={campaign.targetGroup.cities?.join(', ')}>{campaign.targetGroup.cities?.join(', ') || '-'}</div>
                  
                  <div className="text-gray-600">Uprawnienie:</div>
                  <div className="font-medium truncate" title={campaign.targetGroup.permissions?.join(', ')}>{campaign.targetGroup.permissions?.join(', ') || '-'}</div>
                  
                  <div className="text-gray-600">Płeć:</div>
                  <div className="font-medium truncate" title={campaign.targetGroup.genders?.join(', ')}>{campaign.targetGroup.genders?.join(', ') || '-'}</div>
                </div>
              </div>

              <div className="mt-4 border-t pt-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Wolumen wysyłki (Suma dla {campaign.combinations?.length || 0} kombinacji)</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded-lg border">
                    <div className="text-xs text-gray-500 mb-1">Dostępna baza</div>
                    <div className="font-semibold text-lg">{campaign.intersectionAvailableSize?.toLocaleString() || 0}</div>
                  </div>
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <div className="text-xs text-blue-600 mb-1">Do wysyłki (Suma)</div>
                    <div className="font-semibold text-lg text-blue-700">{campaign.plannedSendVolume?.toLocaleString() || 0}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 border-t pt-6">
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4 flex items-center">
              <Target className="h-4 w-4 mr-2" />
              Szczegółowe kombinacje docelowe ({campaign.combinations?.length || 0})
            </h3>
            <div className="border rounded-md overflow-hidden max-h-64 overflow-y-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Kryteria (W|M|U|P)</th>
                    <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">Dostępna Baza</th>
                    <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">Do wysyłki</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {campaign.combinations?.map((c) => (
                    <tr key={c.id} className="hover:bg-gray-50">
                      <td className="px-3 py-2 text-xs text-gray-900">
                        {c.age}, {c.city}, {c.permission}, {c.gender}
                      </td>
                      <td className="px-3 py-2 text-xs font-semibold text-right text-gray-900">
                        {c.availableIntersection.toLocaleString()}
                      </td>
                      <td className="px-3 py-2 text-xs font-semibold text-right text-blue-700">
                        {c.plannedSendVolume.toLocaleString()} <span className="text-gray-400 font-normal ml-1">({c.volumeType === 'max' ? 'Max' : 'Własna'})</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="border-t mt-6 pt-4 flex justify-between items-center text-xs text-gray-500">
            <div>Utworzono: {campaign.createdAt}</div>
            {campaign.updatedAt && <div>Ostatnia edycja: {campaign.updatedAt}</div>}
          </div>
        </div>
      </div>
    </div>
  );
};

function InfoIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4" />
      <path d="M12 8h.01" />
    </svg>
  );
}
