import { useState, useMemo } from 'react';
import { getCampaigns } from '@/utils/localStorage';
import { Database, Filter, Calendar as CalendarIcon, Info } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameDay, addDays, subDays, isWithinInterval, parseISO } from 'date-fns';
import { pl } from 'date-fns/locale';
import { MultiSelect } from './MultiSelect';
import { CITIES, PERMISSIONS, AGE_RANGES, GENDERS } from '@/config';
import { calculateBaseTotal } from '@/utils/baseCalculator';
import { cn } from '@/utils/cn';

import { useEffect } from 'react';
import { shouldFetchDatabaseToday, markDatabaseFetchedToday } from '@/utils/localStorage';
import { RefreshCw } from 'lucide-react';

export const DatabaseStatsComponent: React.FC = () => {
  const [ages, setAges] = useState<string[]>(['Wszyscy']);
  const [cities, setCities] = useState<string[]>(['Wszystkie']);
  const [permissions, setPermissions] = useState<string[]>(['Wszystkie']);
  const [genders, setGenders] = useState<string[]>(['Wszyscy']);
  
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const [selectedDayDetails, setSelectedDayDetails] = useState<{
    date: string;
    baseAvailable: number;
    campaigns: { name: string; blocked: number; sendDate: string }[];
  } | null>(null);

  const campaigns = useMemo(() => getCampaigns(), []);

  useEffect(() => {
    if (shouldFetchDatabaseToday()) {
      fetchDatabaseData();
    }
  }, []);

  const fetchDatabaseData = async () => {
    setIsRefreshing(true);
    try {
      // TODO: Tutaj umieść kod połączenia z Hurtownią danych
      // Zapytanie SQL przygotujesz sam, w tym miejscu możesz wykonać fetch do swojego API.
      await new Promise(resolve => setTimeout(resolve, 1500));
      markDatabaseFetchedToday();
    } catch (error) {
      console.error('Błąd pobierania danych z bazy:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Generate all possible selected combinations
  const selectedCombinations = useMemo(() => {
    const combos: Array<{ age: string; city: string; permission: string; gender: string }> = [];
    const agesList = ages.length > 0 ? ages : ['Wszyscy'];
    const citiesList = cities.length > 0 ? cities : ['Wszystkie'];
    const permList = permissions.length > 0 ? permissions : ['Wszystkie'];
    const genList = genders.length > 0 ? genders : ['Wszyscy'];

    agesList.forEach(age => {
      citiesList.forEach(city => {
        permList.forEach(permission => {
          genList.forEach(gender => {
            combos.push({ age, city, permission, gender });
          });
        });
      });
    });
    return combos;
  }, [ages, cities, permissions, genders]);

  // Total base size for selected combinations
  const totalBaseSize = useMemo(() => {
    return selectedCombinations.reduce((sum, combo) => sum + calculateBaseTotal(combo), 0);
  }, [selectedCombinations]);

  const renderCalendar = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const days = eachDayOfInterval({ start, end });
    const startDayOfWeek = getDay(start);
    const offset = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1; 

    return (
      <div className="bg-white shadow-sm ring-1 ring-gray-200 rounded-xl overflow-hidden mt-4">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-white">
          <h3 className="text-lg font-semibold text-gray-900 capitalize flex items-center">
            {format(currentDate, 'MMMM yyyy', { locale: pl })}
          </h3>
          <div className="flex items-center space-x-1 bg-gray-50 p-1 rounded-lg ring-1 ring-gray-200/50">
            <button 
              onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))}
              className="px-3 py-1.5 rounded-md hover:bg-white hover:shadow-sm text-sm font-medium text-gray-600 transition-all"
            >
              Poprzedni
            </button>
            <button 
              onClick={() => setCurrentDate(new Date())}
              className="px-3 py-1.5 rounded-md hover:bg-white hover:shadow-sm text-sm font-medium text-gray-600 transition-all"
            >
              Dziś
            </button>
            <button 
              onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))}
              className="px-3 py-1.5 rounded-md hover:bg-white hover:shadow-sm text-sm font-medium text-gray-600 transition-all"
            >
              Następny
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-7 border-b border-gray-100 bg-gray-50/50">
          {['Pon', 'Wto', 'Śro', 'Czw', 'Pią', 'Sob', 'Nie'].map((day) => (
            <div key={day} className="py-3 text-center text-[11px] uppercase tracking-wider font-semibold text-gray-500 border-r border-gray-100 last:border-0">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7">
          {Array.from({ length: offset }).map((_, i) => (
            <div key={`empty-${i}`} className="min-h-[110px] p-2 border-r border-b border-gray-100 bg-gray-50/30"></div>
          ))}
          {days.map((day) => {
            let totalBlockedForDay = 0;
            const campaignsAffectingDay: {name: string, blocked: number, sendDate: string}[] = [];

            campaigns.forEach(campaign => {
              const campSendDate = parseISO(campaign.sendDate);
              const blockedInterval = {
                start: subDays(campSendDate, 7),
                end: addDays(campSendDate, 7)
              };

              if (isWithinInterval(day, blockedInterval)) {
                let campaignBlockedVolume = 0;
                
                (campaign.combinations || []).forEach(campCombo => {
                  const isOverlap = selectedCombinations.some(selCombo => {
                    const matchAge = campCombo.age === 'Wszyscy' || selCombo.age === 'Wszyscy' || campCombo.age === selCombo.age;
                    const matchCity = campCombo.city === 'Wszystkie' || selCombo.city === 'Wszystkie' || campCombo.city === selCombo.city;
                    const matchPerm = campCombo.permission === 'Wszystkie' || selCombo.permission === 'Wszystkie' || campCombo.permission === selCombo.permission;
                    const matchGender = campCombo.gender === 'Wszyscy' || selCombo.gender === 'Wszyscy' || campCombo.gender === selCombo.gender;
                    return matchAge && matchCity && matchPerm && matchGender;
                  });

                  if (isOverlap) {
                    campaignBlockedVolume += campCombo.plannedSendVolume;
                  }
                });

                if (campaignBlockedVolume > 0) {
                  totalBlockedForDay += campaignBlockedVolume;
                  campaignsAffectingDay.push({ name: campaign.name, blocked: campaignBlockedVolume, sendDate: campaign.sendDate });
                }
              }
            });

            const baseAvailable = Math.max(0, totalBaseSize - totalBlockedForDay);
            const isBlocked = totalBlockedForDay > 0;
            const isToday = isSameDay(day, new Date());

            return (
              <div 
                key={day.toISOString()} 
                onClick={() => {
                  if (campaignsAffectingDay.length > 0) {
                    setSelectedDayDetails({
                      date: format(day, 'yyyy-MM-dd'),
                      baseAvailable,
                      campaigns: campaignsAffectingDay
                    });
                  }
                }}
                className={cn(
                "min-h-[110px] p-3 border-r border-b border-gray-100 last:border-r-0 relative group transition-all",
                isBlocked ? "bg-rose-50/20 cursor-pointer hover:bg-rose-50/60" : "bg-white hover:bg-gray-50/50",
                campaignsAffectingDay.length > 0 ? "hover:shadow-sm" : ""
              )}>
                {isBlocked && (
                  <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-rose-400 rounded-r-full"></div>
                )}
                
                <div className="flex justify-between items-start mb-2">
                  <span className={cn(
                    "text-sm font-semibold w-7 h-7 flex items-center justify-center rounded-full ring-1 ring-transparent",
                    isToday ? "bg-blue-600 text-white shadow-md ring-blue-600" : "text-gray-700 group-hover:bg-gray-100"
                  )}>
                    {format(day, 'd')}
                  </span>
                  {isBlocked && (
                    <span className="flex h-2.5 w-2.5 mt-2 mr-1">
                      <span className="animate-ping absolute inline-flex h-2.5 w-2.5 rounded-full bg-rose-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                    </span>
                  )}
                </div>
                
                <div className="mt-2 space-y-1">
                  <div className="text-[10px] text-gray-400 uppercase tracking-wide font-medium">Dostępna baza</div>
                  <div className={cn("text-sm font-bold tracking-tight", isBlocked ? "text-rose-700" : "text-emerald-600")}>
                    {baseAvailable.toLocaleString()}
                  </div>
                </div>

                {campaignsAffectingDay.length > 0 && (
                  <div className="mt-2.5 text-[10px] text-rose-700 font-medium bg-rose-100/50 px-2 py-1 rounded-md border border-rose-200/50 truncate flex items-center shadow-sm">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mr-1.5 shrink-0"></span>
                    Zajęte przez {campaignsAffectingDay.length} k.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-6 border-b pb-4">
        <div className="flex items-center space-x-2">
          <Database className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Stan Bazy Danych i Dostępność</h2>
        </div>
        <button
          onClick={fetchDatabaseData}
          disabled={isRefreshing}
          className="flex items-center space-x-1 px-3 py-1.5 border border-gray-300 rounded-md text-sm hover:bg-gray-50 disabled:opacity-50 transition-colors"
        >
          <RefreshCw className={`h-4 w-4 text-blue-600 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span className="font-medium text-gray-700">{isRefreshing ? 'Pobieranie z Hurtowni...' : 'Odśwież dane z Hurtowni'}</span>
        </button>
      </div>

      <div className="mb-6 bg-gray-50 p-4 rounded-lg border">
        <div className="flex items-center space-x-2 mb-4">
          <Filter className="h-5 w-5 text-gray-500" />
          <h3 className="font-medium text-gray-700">Wybierz przekrój bazy do analizy</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MultiSelect label="Wiek" options={AGE_RANGES} selected={ages} onChange={setAges} placeholder="Wybierz wiek" />
          <MultiSelect label="Miasto" options={CITIES} selected={cities} onChange={setCities} placeholder="Wybierz miasto" />
          <MultiSelect label="Uprawnienie" options={PERMISSIONS} selected={permissions} onChange={setPermissions} placeholder="Wybierz uprawnienia" />
          <MultiSelect label="Płeć" options={GENDERS} selected={genders} onChange={setGenders} placeholder="Wybierz płeć" />
        </div>
        
        <div className="mt-4 flex items-center bg-blue-50 p-3 rounded-md border border-blue-100">
          <Info className="h-5 w-5 text-blue-600 mr-2 shrink-0" />
          <div>
            <p className="text-sm text-blue-900">
              Całkowity potencjał bazy dla wybranego przekroju (bez blokad) wynosi: <strong className="text-lg">{totalBaseSize.toLocaleString()}</strong>.
              <br/>
              W poniższym kalendarzu zobaczysz dostępność tej grupy na dany dzień, uwzględniając blokady (7 dni przed i 7 dni po) z zaplanowanych kampanii, które pokrywają się z wybranym przekrojem.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <CalendarIcon className="h-5 w-5 text-gray-600" />
          <h3 className="text-lg font-medium text-gray-800">Kalendarz Dostępności Bazy</h3>
        </div>
        
        {renderCalendar()}
      </div>

      {selectedDayDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-lg overflow-hidden">
            <div className="flex justify-between items-center px-6 py-4 border-b bg-gray-50">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <CalendarIcon className="h-5 w-5 mr-2 text-blue-600" />
                Szczegóły: {selectedDayDetails.date}
              </h3>
              <button onClick={() => setSelectedDayDetails(null)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
              </button>
            </div>
            <div className="p-6">
              <div className="mb-4">
                <p className="text-sm text-gray-500">Dostępna baza w tym dniu dla wybranego profilu:</p>
                <p className="text-xl font-bold text-gray-900">{selectedDayDetails.baseAvailable.toLocaleString()}</p>
              </div>
              <h4 className="text-sm font-semibold text-gray-900 border-b pb-2 mb-3">Kampanie konsumujące bazę (±7 dni):</h4>
              <ul className="space-y-3">
                {selectedDayDetails.campaigns.map((camp, idx) => (
                  <li key={idx} className="bg-red-50 p-3 rounded-md border border-red-100 flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-gray-900 text-sm">{camp.name}</div>
                      <div className="text-xs text-gray-500">Data wysyłki: {camp.sendDate}</div>
                    </div>
                    <div className="text-red-700 font-bold text-sm">
                      -{camp.blocked.toLocaleString()}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t bg-gray-50 px-6 py-4 flex justify-end">
              <button
                onClick={() => setSelectedDayDetails(null)}
                className="px-4 py-2 bg-white border border-gray-300 rounded-md text-sm font-medium hover:bg-gray-50"
              >
                Zamknij
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
