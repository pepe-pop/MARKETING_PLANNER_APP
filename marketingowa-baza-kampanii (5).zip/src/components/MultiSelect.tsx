import React, { useState, useRef, useEffect } from 'react';
import { cn } from '@/utils/cn';
import { ChevronDown, Check } from 'lucide-react';

interface MultiSelectProps {
  options: string[];
  selected: string[];
  onChange: (selected: string[]) => void;
  label?: string;
  placeholder?: string;
}

export const MultiSelect: React.FC<MultiSelectProps> = ({ options, selected, onChange, label, placeholder = 'Wybierz...' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const toggleOption = (option: string) => {
    if (option === 'Wszystkie' || option === 'Wszyscy') {
      if (selected.includes(option)) {
        onChange([]);
      } else {
        onChange([option]);
      }
      return;
    }

    let newSelected = [...selected];
    newSelected = newSelected.filter(item => item !== 'Wszystkie' && item !== 'Wszyscy');

    if (newSelected.includes(option)) {
      newSelected = newSelected.filter(item => item !== option);
    } else {
      newSelected.push(option);
    }
    onChange(newSelected);
  };

  const displayValue = selected.length === 0 
    ? placeholder 
    : selected.length === 1 
      ? selected[0] 
      : `Wybrano: ${selected.length}`;

  return (
    <div className="space-y-1 relative" ref={containerRef}>
      {label && <label className="block text-sm font-medium text-gray-700">{label}</label>}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between bg-white border border-gray-300 text-gray-700 py-2 px-3 rounded-md shadow-sm text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      >
        <span className="truncate">{displayValue}</span>
        <ChevronDown className="h-4 w-4 text-gray-400" />
      </button>

      {isOpen && (
        <div className="absolute z-50 mt-1 w-full bg-white shadow-lg max-h-60 rounded-md py-1 text-base ring-1 ring-black ring-opacity-5 overflow-auto focus:outline-none sm:text-sm">
          {options.map((option) => {
            const isSelected = selected.includes(option);
            return (
              <div
                key={option}
                onClick={() => toggleOption(option)}
                className={cn(
                  "cursor-pointer select-none relative py-2 pl-3 pr-9 hover:bg-gray-50",
                  isSelected ? "text-blue-900 bg-blue-50" : "text-gray-900"
                )}
              >
                <span className={cn("block truncate", isSelected ? "font-semibold" : "font-normal")}>
                  {option}
                </span>
                {isSelected && (
                  <span className="absolute inset-y-0 right-0 flex items-center pr-4 text-blue-600">
                    <Check className="h-4 w-4" />
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
