// Prosta symulacja przecięcia bazy danych. W rzeczywistym środowisku tu wysłane zostałoby
// zapytanie COUNT do Hurtowni Danych

// Calculate stable total base size for a combination
export function calculateBaseTotal(combo: { age: string; city: string; permission: string; gender: string }) {
  const hashStr = `${combo.age}-${combo.city}-${combo.permission}-${combo.gender}`;
  let hash = 0;
  for (let i = 0; i < hashStr.length; i++) {
    hash = ((hash << 5) - hash) + hashStr.charCodeAt(i);
    hash |= 0;
  }
  const pseudoRandom = Math.abs(hash) / 2147483647;

  let baseSize = 1000000;

  if (combo.age && combo.age !== 'Wszyscy') baseSize *= 0.12; 
  if (combo.city && combo.city !== 'Wszystkie') baseSize *= 0.08;
  if (combo.gender && combo.gender !== 'Wszyscy') baseSize *= 0.5;
  if (combo.permission && combo.permission !== 'Wszystkie') baseSize *= 0.7;
  
  return Math.floor(baseSize * (0.8 + pseudoRandom * 0.4));
}

import { Campaign } from '@/types/campaign';
import { parseISO, subDays, addDays, isWithinInterval } from 'date-fns';

export function calculateIntersection(
  combo: { age: string; city: string; permission: string; gender: string }, 
  sendDate: string,
  allCampaigns: Campaign[] = [],
  currentCampaignId?: string
) {
  // Hash function to make "randomness" deterministic based on combination + date
  const hashStr = `${combo.age}-${combo.city}-${combo.permission}-${combo.gender}-${sendDate}`;
  let hash = 0;
  for (let i = 0; i < hashStr.length; i++) {
    hash = ((hash << 5) - hash) + hashStr.charCodeAt(i);
    hash |= 0;
  }
  const pseudoRandom = Math.abs(hash) / 2147483647;

  const totalIntersection = calculateBaseTotal(combo);
  
  // Baseline random blocked from other systems
  const blockedFactor = 0.05 + (pseudoRandom * 0.1); 
  let blockedCount = Math.floor(totalIntersection * blockedFactor);
  
  // Odejmij zablokowaną bazę z innych zaplanowanych kampanii (7 dni przed i 7 dni po)
  if (sendDate) {
    try {
      const currentSendDate = parseISO(sendDate);
      
      allCampaigns.forEach(campaign => {
        if (currentCampaignId && campaign.id === currentCampaignId) return; // Pomiń samą siebie przy edycji
        if (campaign.status === 'failed') return; // Pomiń nieudane kampanie
        
        const campDate = parseISO(campaign.sendDate);
        const blockedInterval = {
          start: subDays(campDate, 7),
          end: addDays(campDate, 7)
        };
        
        if (isWithinInterval(currentSendDate, blockedInterval)) {
          // Sprawdź czy kampania zajmuje ten sam przekrój bazy
          (campaign.combinations || []).forEach(campCombo => {
            const matchAge = campCombo.age === 'Wszyscy' || combo.age === 'Wszyscy' || campCombo.age === combo.age;
            const matchCity = campCombo.city === 'Wszystkie' || combo.city === 'Wszystkie' || campCombo.city === combo.city;
            const matchPerm = campCombo.permission === 'Wszystkie' || combo.permission === 'Wszystkie' || campCombo.permission === combo.permission;
            const matchGender = campCombo.gender === 'Wszyscy' || combo.gender === 'Wszyscy' || campCombo.gender === combo.gender;
            
            if (matchAge && matchCity && matchPerm && matchGender) {
              blockedCount += campCombo.plannedSendVolume;
            }
          });
        }
      });
    } catch (e) {
      console.error("Błąd parsowania daty", e);
    }
  }
  
  const availableIntersection = Math.max(0, totalIntersection - blockedCount);
  
  return {
    totalIntersection,
    availableIntersection,
    blockedCount: totalIntersection - availableIntersection
  };
}
