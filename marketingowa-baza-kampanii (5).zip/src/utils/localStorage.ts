import { Campaign, DatabaseStats } from '@/types/campaign';
import { format } from 'date-fns';

const CAMPAIGNS_KEY = 'marketing_campaigns';
const DATABASE_STATS_KEY = 'database_stats';
const LAST_FETCH_KEY = 'last_database_fetch';

export const saveCampaign = (campaign: Campaign) => {
  const campaigns = getCampaigns();
  campaigns.push(campaign);
  localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns));
  incrementVersion();
};

export const getCampaignsVersion = (): string => {
  return localStorage.getItem('campaigns_version') || '0';
};

const incrementVersion = () => {
  const current = parseInt(getCampaignsVersion(), 10);
  localStorage.setItem('campaigns_version', (current + 1).toString());
};

export const getCampaigns = (): Campaign[] => {
  const stored = localStorage.getItem(CAMPAIGNS_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const updateCampaign = (id: string, updated: Partial<Campaign>) => {
  const campaigns = getCampaigns();
  const index = campaigns.findIndex(c => c.id === id);
  if (index !== -1) {
    campaigns[index] = { ...campaigns[index], ...updated };
    localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns));
    incrementVersion();
  }
};

export const saveDatabaseStats = (stats: DatabaseStats) => {
  localStorage.setItem(DATABASE_STATS_KEY, JSON.stringify(stats));
};

export const getDatabaseStats = (): DatabaseStats => {
  const stored = localStorage.getItem(DATABASE_STATS_KEY);
  return stored 
    ? JSON.parse(stored) 
    : { totalClients: 10000, availableClients: 8500, lastUpdated: format(new Date(), 'yyyy-MM-dd') };
};

export const shouldFetchDatabaseToday = (): boolean => {
  const lastFetch = localStorage.getItem(LAST_FETCH_KEY);
  const today = format(new Date(), 'yyyy-MM-dd');
  return !lastFetch || lastFetch !== today;
};

export const markDatabaseFetchedToday = () => {
  const today = format(new Date(), 'yyyy-MM-dd');
  localStorage.setItem(LAST_FETCH_KEY, today);
};
