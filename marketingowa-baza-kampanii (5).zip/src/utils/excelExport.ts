import * as XLSX from 'xlsx';
import { Campaign } from '@/types/campaign';
import { format } from 'date-fns';

export const exportCampaignsToExcel = (campaigns: Campaign[]) => {
  const formattedData = campaigns.map(campaign => ({
    'Nazwa kampanii': campaign.name,
    'Opiekun linii': campaign.manager,
    'Planowana data wysyłki': campaign.sendDate,
    'Kanał kontaktu': campaign.channel,
    'Treść komunikatu': campaign.messageContent || '-',
    'Grupa docelowa - Wiek': campaign.targetGroup.ages?.join(', ') || '-',
    'Grupa docelowa - Miasto': campaign.targetGroup.cities?.join(', ') || '-',
    'Grupa docelowa - Uprawnienie': campaign.targetGroup.permissions?.join(', ') || '-',
    'Grupa docelowa - Płeć': campaign.targetGroup.genders?.join(', ') || '-',
    'Liczba kombinacji': campaign.combinations?.length || 0,
    'Szczegóły kombinacji': campaign.combinations?.map(c => `[${c.age}, ${c.city}, ${c.permission}, ${c.gender}] Baza: ${c.availableIntersection} -> Wysyłka: ${c.plannedSendVolume}`).join(' | ') || '-',
    'Wielkość przecięcia bazy (Suma)': campaign.intersectionTotalSize || 0,
    'Dostępna baza po filtrach (Suma)': campaign.intersectionAvailableSize || 0,
    'Planowany wolumen wysyłki (Suma)': campaign.plannedSendVolume || 0,
    'Status realizacji': campaign.status,
    'Data utworzenia': campaign.createdAt,
    'Data ostatniej edycji': campaign.updatedAt || '-'
  }));

  const worksheet = XLSX.utils.json_to_sheet(formattedData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Plan kampanii');

  const date = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
  const fileName = `plan kampanii_${date}.xlsx`;

  XLSX.writeFile(workbook, fileName);
};
