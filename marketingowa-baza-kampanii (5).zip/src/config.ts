// TODO: Tutaj możesz dowolnie edytować i dodawać nowe miasta do listy rozwijanej
export const CITIES = [
  'Wszystkie',
  'Warszawa',
  'Kraków',
  'Łódź',
  'Wrocław',
  'Poznań',
  'Gdańsk',
  'Szczecin',
  'Bydgoszcz',
  'Lublin',
  'Białystok',
  'Katowice'
];

// TODO: Tutaj możesz zdefiniować listę uprawnień (zgód) dla bazy
export const PERMISSIONS = [
  'Wszystkie',
  'Zgoda marketingowa ogólna',
  'Zgoda na komunikację Email',
  'Zgoda na komunikację SMS',
  'Zgoda na profilowanie',
  'Zgoda na kontakt telefoniczny'
];

export const AGE_RANGES = [
  'Wszyscy',
  '18-24',
  '25-29',
  '30-34',
  '35-39',
  '40-44',
  '45-49',
  '50-54',
  '55-59',
  '60+'
];

export const GENDERS = [
  'Wszyscy',
  'Kobieta',
  'Mężczyzna'
];
